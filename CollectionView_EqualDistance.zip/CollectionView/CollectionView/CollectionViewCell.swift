//
//  CollectionViewCell.swift
//  CollectionView
//
//  Created by junaid on 4/26/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fruitImage: UIImageView!
    
    
}
