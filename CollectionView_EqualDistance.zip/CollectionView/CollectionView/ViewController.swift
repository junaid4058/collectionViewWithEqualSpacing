//
//  ViewController.swift
//  CollectionView
//
//  Created by junaid on 4/26/17.
//  Copyright © 2017 junaid. All rights reserved.
//

import UIKit

var SCREEN_WIDTH = UIScreen.main.bounds.size.width
var SCREEN_HEIGHT = UIScreen.main.bounds.size.height
var BASE_SCREEN_HEIGHT:CGFloat = 736.0
var SCREEN_MAX_LENGTH = max(SCREEN_WIDTH, SCREEN_HEIGHT)
var ASPECT_RATIO_RESPECT_OF_7P = SCREEN_MAX_LENGTH / BASE_SCREEN_HEIGHT

let MINIMUM_INTERITEM_SPACING:CGFloat = 10 //My Default Inter Cell Spacing for iphone 7plus as i have designed in it.
var ITEM_WIDTH:CGFloat  = 138 //for iPhone 7 plus.initial value
var ITEM_HEIGHT:CGFloat = 138 //for iphone 7 plus.initial value
let NUMBER_OF_CELLS_IN_PORTRAIT:CGFloat = 2
let NUMBER_OF_CELLS_IN_LANDSCAPE:CGFloat = 5


class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var collectionView: UICollectionView!
    
    var imageArray:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        //Sample data
        imageArray = ["image5","image2","image3","image4","image5","image4","image5","image4","image5"]
        
        
        //Show Cell number according to device's starting orientation. Device might be in landscape mode first.
        self.initialCollectionData()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func initialCollectionData() {
        let orientation = UIApplication.shared.statusBarOrientation
        if orientation == .portrait {
            self.calculateCellSize(screenWidth:SCREEN_WIDTH ,cellItem: NUMBER_OF_CELLS_IN_PORTRAIT)
        }
        else {
            self.calculateCellSize(screenWidth:SCREEN_WIDTH ,cellItem: NUMBER_OF_CELLS_IN_LANDSCAPE)
        }
    }
    
    //This method calculate cellsize according to cell number.
    func  calculateCellSize(screenWidth:CGFloat , cellItem:CGFloat) {
       // ITEM_WIDTH = (screenWidth - MINIMUM_INTERITEM_SPACING * (cellItem + 1) * ASPECT_RATIO_RESPECT_OF_7P  * (cellItem-1)) / cellItem  - 1// This 1 has been subtracted from ITEM_WIDTH to remove mantissa
        ITEM_WIDTH = (screenWidth - MINIMUM_INTERITEM_SPACING * (cellItem + 1) * ASPECT_RATIO_RESPECT_OF_7P) / cellItem - 1;
        ITEM_HEIGHT = ITEM_WIDTH
    }
    
    //This method calculate cell number according to orientation.
    func findCellItem(screenWidth:CGFloat)  {
        let orientation = UIDevice.current.orientation
        if orientation == .portrait {
            self.calculateCellSize(screenWidth:screenWidth ,cellItem: NUMBER_OF_CELLS_IN_PORTRAIT) //You have chosen 2 cells to show in portrait
        }
        else {
            self.calculateCellSize(screenWidth:screenWidth ,cellItem: NUMBER_OF_CELLS_IN_LANDSCAPE) ////You have chosen 3 cells to show in portrait
        }
    }
    
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        return imageArray.count
        
    }
    
    
    //During orientation change this method is called everytime.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { context in
            
            context.viewController(forKey: UITransitionContextViewControllerKey.from)
            //Below two methods do the trick
            self.findCellItem(screenWidth: size.width)
            self.collectionView.collectionViewLayout.invalidateLayout()
        }, completion: {
            _ in
        })
        
    }
    
    
    
    
  //Collection View delegate methods
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        let collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        collectionCell.fruitImage.image = UIImage.init(named: imageArray[indexPath.row])
        return collectionCell
        
        
    }
    
    
     public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: ITEM_WIDTH , height: ITEM_HEIGHT )
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
       return MINIMUM_INTERITEM_SPACING * ASPECT_RATIO_RESPECT_OF_7P
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return MINIMUM_INTERITEM_SPACING * ASPECT_RATIO_RESPECT_OF_7P
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, MINIMUM_INTERITEM_SPACING*ASPECT_RATIO_RESPECT_OF_7P, 0, MINIMUM_INTERITEM_SPACING*ASPECT_RATIO_RESPECT_OF_7P)
    }
    
    

}

